# Getting Started with Create React App

## Installation
In the project directory (frontend folder), you can run: `npm install`.



## Run the app
Use `npm run start` to run the app in the development mode.


## API
`chat/` for normal chat

`chatstream/` for streaming
