# retriever-guide
An AI chatbot that takes the role of an advisor who can help the user navigate UMBC
